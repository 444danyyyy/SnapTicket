package SnapTicket;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class SnapTicketGUI extends JFrame {

    // Lista utenti e ticket
    private ArrayList<Utente> utenti;
    private ArrayList<Ticket> tickets;

    // Utente attualmente loggato
    private Utente utenteLoggato;

    // Contatore ID ticket
    private int contatore = 1;

    // Layout per cambiare schermate
    private CardLayout layout = new CardLayout();
    private JPanel mainPanel = new JPanel(layout);

    public SnapTicketGUI() {
        setTitle("Snap Ticket - Help Desk System");
        setSize(600, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Caricamento dati
        utenti = GestoreDati.caricaUtenti();
        tickets = GestoreDati.caricaTickets();

        // Avvio schermata login
        initLogin();

        add(mainPanel);
        setVisible(true);
    }

    // SCHERMATA LOGIN
    private void initLogin() {

        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(new Color(245, 245, 245));

        JPanel panel = new JPanel();
        panel.setPreferredSize(new Dimension(320, 300));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createLineBorder(new Color(220,220,220), 1));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel titolo = new JLabel("Snap Ticket");
        titolo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titolo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JTextField user = new JTextField();
        user.setMaximumSize(new Dimension(250, 35));
        user.setBorder(BorderFactory.createTitledBorder("Username"));

        JPasswordField pass = new JPasswordField();
        pass.setPreferredSize(new Dimension(200, 35));
        pass.setBorder(BorderFactory.createTitledBorder("Password"));
        pass.setEchoChar('•');

        JButton eye = new JButton("👁");
        eye.setPreferredSize(new Dimension(50, 35));
        eye.setFocusPainted(false);

        final boolean[] visible = {false};

        eye.addActionListener(e -> {
            visible[0] = !visible[0];

            if (visible[0]) {
                pass.setEchoChar((char) 0);
                eye.setText("Ø");
            } else {
                pass.setEchoChar('•');
                eye.setText("👁");
            }
        });

        JPanel passPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
        passPanel.setMaximumSize(new Dimension(300, 40));
        passPanel.setBackground(Color.WHITE);

        passPanel.add(pass);
        passPanel.add(eye);

        JButton login = new JButton("Accedi");
        login.setAlignmentX(Component.CENTER_ALIGNMENT);
        login.setFocusPainted(false);
        login.setBackground(new Color(0, 150, 136));
        login.setForeground(Color.WHITE);

        login.addActionListener(e -> {
            for (Utente u : utenti) {
                if (u.nome.equals(user.getText()) &&
                        u.password.equals(new String(pass.getPassword()))) {

                    utenteLoggato = u;

                    if (u.ruolo.equals("DIPENDENTE")) {
                        initDipendente();
                        layout.show(mainPanel, "DIP");
                    } else {
                        initTecnico();
                        layout.show(mainPanel, "TEC");
                    }
                    return;
                }
            }

            JOptionPane.showMessageDialog(this, "Credenziali errate ❌");
        });

        panel.add(Box.createVerticalStrut(20));
        panel.add(titolo);
        panel.add(Box.createVerticalStrut(20));
        panel.add(user);
        panel.add(Box.createVerticalStrut(10));
        panel.add(passPanel);
        panel.add(Box.createVerticalStrut(20));
        panel.add(login);

        wrapper.add(panel);
        mainPanel.add(wrapper, "LOGIN");
    }

    // SCHERMATA DIPENDENTE
    private void initDipendente() {

        JPanel p = new JPanel(new BorderLayout(10,10));
        p.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));

        JLabel welcome = new JLabel("Benvenuto " + utenteLoggato.nome);
        welcome.setFont(new Font("Segoe UI", Font.BOLD, 18));

        JComboBox<String> problemi = new JComboBox<>(new String[]{
                "Stampante", "WiFi", "Software", "Altro..."
        });

        JTextField altro = new JTextField();
        altro.setEnabled(false);

        problemi.addActionListener(e ->
                altro.setEnabled(problemi.getSelectedItem().equals("Altro..."))
        );

        JComboBox<String> prio = new JComboBox<>(new String[]{
                "Bassa", "Media", "Alta"
        });

        JButton invia = new JButton("Apri Ticket");

        invia.addActionListener(e -> {
            String desc = problemi.getSelectedItem().toString();
            if (desc.equals("Altro...")) desc = altro.getText();

            Ticket t = new Ticket(contatore++, utenteLoggato.nome,
                    utenteLoggato.dipartimento, desc,
                    prio.getSelectedItem().toString());

            tickets.add(t);
            JOptionPane.showMessageDialog(this, "Ticket creato ✅");
        });

        JButton logout = new JButton("Logout");
        logout.addActionListener(e -> layout.show(mainPanel, "LOGIN"));

        JPanel form = new JPanel(new GridLayout(6,1,10,10));
        form.add(new JLabel("Problema"));
        form.add(problemi);
        form.add(altro);
        form.add(new JLabel("Priorità"));
        form.add(prio);
        form.add(invia);

        p.add(welcome, BorderLayout.NORTH);
        p.add(form, BorderLayout.CENTER);
        p.add(logout, BorderLayout.SOUTH);

        mainPanel.add(p, "DIP");
    }

    // SCHERMATA TECNICO
    private void initTecnico() {

        JPanel p = new JPanel(new BorderLayout(10,10));
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        DefaultListModel<Ticket> model = new DefaultListModel<>();
        JList<Ticket> lista = new JList<>(model);

        JButton aggiorna = new JButton("Aggiorna");
        JButton chiudi = new JButton("Chiudi Ticket");
        JButton logout = new JButton("Logout");

        aggiorna.addActionListener(e -> {
            model.clear();
            String[] ordine = {"Alta", "Media", "Bassa"};

            for (String pr : ordine) {
                for (Ticket t : tickets) {
                    if (!t.completato && t.priorita.equals(pr)) {
                        model.addElement(t);
                    }
                }
            }
        });

        chiudi.addActionListener(e -> {
            Ticket sel = lista.getSelectedValue();
            if (sel != null) {
                sel.completato = true;
                model.removeElement(sel);
            }
        });

        logout.addActionListener(e -> layout.show(mainPanel, "LOGIN"));

        JPanel top = new JPanel();
        top.add(aggiorna);
        top.add(chiudi);
        top.add(logout);

        p.add(top, BorderLayout.NORTH);
        p.add(new JScrollPane(lista), BorderLayout.CENTER);

        mainPanel.add(p, "TEC");
    }
}