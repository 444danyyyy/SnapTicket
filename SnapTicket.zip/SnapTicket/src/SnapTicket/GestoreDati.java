package SnapTicket;

import java.util.ArrayList;
public class GestoreDati {


    public static ArrayList<Utente> caricaUtenti() {
        ArrayList<Utente> utenti = new ArrayList<>();

        utenti.add(new Utente("daniele", "pass1", "DIPENDENTE", "Informatica"));
        utenti.add(new Utente("kevin", "pass2", "DIPENDENTE", "Elettronica"));
        utenti.add(new Utente("federico", "pass3", "DIPENDENTE", "Amministrazione"));
        utenti.add(new Utente("marco", "pass4", "DIPENDENTE", "Marketing"));
        utenti.add(new Utente("tecnico", "admin", "TECNICO", "N/A"));

        return utenti;
    }

    public static ArrayList<Ticket> caricaTickets() {
        return new ArrayList<>(); 
    }
}